import express from "express";
import {
  createBooking,
  getMyBookings,
  cancelBooking,
} from "../controllers/bookingController.js";

const router = express.Router();

router.post('/book', createBooking);
router.get('/my-bookings/:userId', getMyBookings);
router.delete('/cancel/:bookingId', cancelBooking);

export default router;
