import Booking from "../models/bookingModel.js";
import User from "../models/userModel.js";
import { sendNotification } from "./notificationController.js";
import { errorHandler } from './../utilis/error.js';


export const createBooking = async (req, res, next) => {
    console.log('Book request');
  const { userId, busNo, date, source, destination, paymentType } = req.body;
   console.log(req.body);
  try {
    // Check if the user exists
    const existingUser = await User.findById(userId);
    if (!existingUser) {
      return next(errorHandler(404, 'You are not allowed to update this user'));
    }

    // Check if the number of bookings for the bus on the specified date exceeds 100
    const existingBookingCount = await Booking.countDocuments({ busNo, date, status: 'active' });
    if (existingBookingCount >= 100) {
        return next(errorHandler(404, 'No seats available'));
    }

    // If the user is a faculty and paymentType is PayLater, increment payment dues
    if (existingUser.accountType === "faculty" && paymentType === "PayLater") {
      existingUser.paymentDues += 50;
      await existingUser.save(); // Save updated user details
    }

    const bookings = new Booking({
      user: userId,
      busNo,
      date,
      source,
      destination,
    });

    await bookings.save();

    const message =`You have successfully made a booking for the bus ${busNo} from ${source} to ${destination} on ${date}`;

    // Send notification to the user
   await sendNotification({ userIds: [userId], message });

    return res.status(201).json({ message: "Booking created successfully", bookings });
  } catch (error) {
    console.error("Error creating booking:", error);
    return next(errorHandler(500, 'Internal Server Error: Unable to create booking'));
  }
};

export const getMyBookings = async (req, res, next) => {
  const { userId } = req.params;
  try {
    const user = await User.findById(userId);
    if (!user) {
      return next(errorHandler(404, 'User not found'));
    }

    const bookings = await Booking.find({ user: userId }).sort({ createdAt: -1 });
    return res.status(200).json({ message: 'Bookings fetched', bookings });
  } catch (error) {
    console.error('Error fetching bookings:', error);
    return next(errorHandler(500, 'Internal Server Error: Unable to fetch bookings'));
  }
};

export const cancelBooking = async (req, res, next) => {
  const { bookingId } = req.params;
  const { userId } = req.body || {};

  try {
    const booking = await Booking.findById(bookingId);
    if (!booking) {
      return next(errorHandler(404, 'Booking not found'));
    }

    if (userId && booking.user.toString() !== userId.toString()) {
      return next(errorHandler(403, 'You are not allowed to cancel this booking'));
    }

    if (booking.status === 'cancelled') {
      return res.status(200).json({ message: 'Booking already cancelled', booking });
    }

    booking.status = 'cancelled';
    booking.cancelledAt = new Date();
    await booking.save();

    // Refund any pending dues that were added at booking time for faculty PayLater
    const user = await User.findById(booking.user);
    if (user && user.accountType === 'faculty' && (user.paymentDues || 0) >= 50) {
      user.paymentDues -= 50;
      await user.save();
    }

    const message = `Your booking for bus ${booking.busNo} from ${booking.source} to ${booking.destination} on ${booking.date} has been cancelled.`;
    try {
      await sendNotification({ userIds: [booking.user.toString()], message });
    } catch (err) {
      console.log('Notification send failed:', err);
    }

    return res.status(200).json({ message: 'Booking cancelled successfully', booking });
  } catch (error) {
    console.error('Error cancelling booking:', error);
    return next(errorHandler(500, 'Internal Server Error: Unable to cancel booking'));
  }
};
